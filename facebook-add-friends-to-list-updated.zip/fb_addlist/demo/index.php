<!--
 /*
 * Facebook Style Add Friends Script
 * http://www.amitpatil.com/
 *
 * @version
 * 1.0 (May 20 2010)
 * 
 * @copyright
 * Copyright (C) 2010-2011 
 *
 * @Auther
 * Amit Patil (www.amitpatil.me)
 * Maharashtra (India) 
 *
 * @license
 * This file is part of Facebook Style Add Friends.
 * 
 * Facebook Style Add Friends Script is freeware script. you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Facebook Style Add Friends Script is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this script.  If not, see <http://www.gnu.org/copyleft/lesser.html>.
 */
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
 <head>
  <title> Facebook Style Add Friends Script </title>
 </head>
 <script src="js/jquery.js"></script>
 <script src="js/facebookStyleInput.js"></script>
 <script type="text/javascript">
	var mainHolder	 = "#fb_holder";
	var inputBox	 = "#fb_inputbox";
	var ajaxFilePath = "ajax_server.php";
 </script>
 <link rel="stylesheet" type="text/css" href="styles/facebookStyleInput.css">
 <body>
	<div class="about">
		<h2>Facebook Style Add Friends to List Script</h2>
		<div class="auther">Program By : Amit Patil<br> Contact : <img src="mail.jpg"></div>
	</div>
	<div style="border: 1px dashed #C0BC16;background:#63CB45;padding:5px;">Version Updates : Now you can post selected list items to next page.</div>
	<div class="main">
		<div class="title">Demo</div>
		<div class="demo">
			<div id="fb_holder">
				<input type="text" name="friends" id="fb_inputbox">
			</div>
			<textarea type="text" id="selected_ids" disabled></textarea>
		</div>
	</div>
 </body>
</html>
